public class askisi5{

     public static void main(String []args){
        int n;
        for(n=1; n<=3; n++)
        {
            System.out.println("**");
        }
     }
}