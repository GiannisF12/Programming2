import java.lang.Math;
public class askisi7{
     public static void main(String []args){
        double x = 30;
        System.out.println(Math.sqrt(x));
     }
}