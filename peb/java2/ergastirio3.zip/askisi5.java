public class askisi5{
     public static void main(String []args){
        String txt = "Test";
        txt=txt.toUpperCase();
        System.out.println(txt);
     }
}