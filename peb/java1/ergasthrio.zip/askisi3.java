public class askisi3{

     public static void main(String []args){
         int x=2;
         double i=0,sum1=0,sum2=0,sum3=0,sum4=0;
         for(i=1; i<=10; i++)
            {
                sum1=x*i;
                sum2=x/i;
                sum3=x+i;
                sum4=x%i;
                System.out.println("polaplasiasmos="+sum1+"\ndiv="+sum2+"\nprosthesh="+sum3+"\nmod="+sum4+"\n");
            }
     }
}
//askisi3:otan to x<i to div(to piliko) kai to mod(upolipo) ths diairesis ginontai mod=0 kai div=2 se kathe epanalipsi.

//askisi3 kai askisi4 mazi.