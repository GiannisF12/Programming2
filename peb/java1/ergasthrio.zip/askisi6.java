public class askisi6{

     public static void main(String []args){
        int n;
        String sum="";
        for(n=1;n<=4; n++)
        {
            
            sum=sum+"*";
            System.out.println(sum);
        }
     }
}