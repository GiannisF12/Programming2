class Cat{

    String name;

    static int numberOfLegs;
    static int numberOfEars;

    void catAction(int action)
    {
        if(action==1)
        {
            System.out.println("niauuu");
        }
        if(action==2)
        {
            System.out.println("pouuurr");
        }

}