public class askisi6{
     public static void main(String []args){
        String txt = "Test";
        int i;
        for(i=0;i<4;i++)
        {
            char txt2=txt.charAt(i);
            System.out.println(txt2);
        }
     }
}