public class askisi7{

     public static void main(String []args){
        int x=3;
        switch(x)
        {
            case 1:
            System.out.println("ianouarios");
            break;
            
            case 2:
            System.out.println("febrouarios");
            break;
            
            case 3:
            System.out.println("martios");
            break;
            
            case 4:
            System.out.println("aprilios");
            break;
            
            case 5:
            System.out.println("maios");
            break;
            
            case 6:
            System.out.println("iounios");
            break;
            
            case 7:
            System.out.println("ioulios");
            break;
            
            case 8:
            System.out.println("augoustos");
            break;
            
            case 9:
            System.out.println("septembrio");
            break;
            
            case 10:
            System.out.println("oktombrios");
            break;
            
            case 11:
            System.out.println("noembrios");
            break;
            
            case 12:
            System.out.println("dekembrios");
            break;
            
        }
     }
}