public class Human{

    String name;
    int height;
    double weight;

    static int numberOfEyes;

    void say(int response)
    {
        if(response ==1)
        {
            System.out.println("Hi");
        }
        if(response ==2)
        {
            System.out.println("Hello");
        }
        if(response ==3)
        {
            System.out.println("My name is" + human1.name + ",what's yours?");
        }
        if(response ==4)
        {
            System.out.println("Nice to meet you, my name is" + human2.name );
        }


}
//gia thn askhsh 2