public class askisi2{

     public static void main(String []args){
         int x=2,i=0,sum=0;
         for(i=1; i<=10; i++)
            {
                sum=x*i;
                System.out.println(sum);
            }
     }
}